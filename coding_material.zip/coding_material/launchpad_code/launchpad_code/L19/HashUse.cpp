#include <iostream>
#include "HashTable.h"
#include <unordered_map>
using namespace std;

int main() {
	mymap m;
	m.insert("abc", 10);
	m.insert("ghi", 20);
	m.insert("def", 30);
	m.insert("klm", 40);
	m.insert("xyz", 50);
	m.insert("abc", 50);
	cout << m.num_elements() << endl;
	m.remove("abc");
	cout << m.num_elements() << endl;
	cout << m.get_value("abc") << endl;

	unordered_map<char, int> map;
	map['a'] = 10;
	cout << map['a'] << endl;
	cout << map['b'] << endl;
}

