#ifndef NODE_H
#define NODE_H 1
class Node {
	public:
		char* key;
		int value;
		Node* next;

	public:
		Node(char* key, int data) {
			this->key = new char[strlen(key)];
			strcpy(this->key, key);
			this->value = data;
			this->next = NULL;
		}

		~Node() {
			delete key;
			if (next != NULL) {
				delete next;
			}
		}
};
#endif
