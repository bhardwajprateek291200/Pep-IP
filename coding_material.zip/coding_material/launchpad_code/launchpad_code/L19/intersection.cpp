#include <iostream>
#include <unordered_map>
using namespace std;

int main() {
	int a[] = {1,3,5,6,2,9, 5,1,2,5};
	int b[] = {5,2,7,10,6,5, 1,1,1,2};
	unordered_map<int, int> map;
	for (int i = 0; i < 10; i++) {
		if (map[a[i]] > 0) {
			map[a[i]] =  map[a[i]] + 1;
		} else {
			 map[a[i]] = 1;
		}
	}

	for (int i = 0; i < 10; i++) {
		if (map[b[i]] > 0) {
			cout << b[i] << endl;
			map[b[i]] = map[b[i]] - 1;
		}
	}
	
	
	
/*	
	unordered_map<int, bool> map;
	for (int i = 0; i < 6; i++) {
		map[a[i]] = true;
	}

	for (int i = 0; i < 7; i++) {
		if (map[b[i]]) {
			cout << b[i] << endl;
		}
	}
*/
}

