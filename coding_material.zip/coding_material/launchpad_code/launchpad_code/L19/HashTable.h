#ifndef HASHTABLE_H
#define HASHTABLE_H
#include <cstring>
#include "Node.h"
class mymap {
	int tablesize;
	Node** buckets;
	int count;
	
	int hash(char* key) {
		int len = strlen(key);
		int output = 0;
		int current_multiplication_factor = 1;
		for (int i = len - 1; i >=0; i--) {
			output += 
				(current_multiplication_factor * key[i]) % tablesize;
			current_multiplication_factor *= 37;
		}
		return output % tablesize;
	}

	void rehash() {
		tablesize *= 2;
		Node** temp = buckets;
		buckets = new Node*[tablesize];
		count = 0;
		int prev_table_size = tablesize/2;
		for (int i = 0; i < prev_table_size; i++) {
			Node* head = temp[i];
			while (head != NULL) {
				insert(head->key, head->value);
				head = head->next;
			}
			delete temp[i];
		}
		delete [] temp;
	}

	public:
		mymap() {
			tablesize = 11;
			buckets = new Node*[tablesize];
			for (int i = 0; i < tablesize; i++) {
				buckets[i] = NULL;
			}
			count = 0;
		}

		~mymap() {
			for (int i = 0; i < tablesize; i++) {
				delete buckets[i];
			}
			delete [] buckets;
		}

		void remove(char* key) {
			int bucketIndex = hash(key);
			Node* headBucket = buckets[bucketIndex];
			Node* prev = NULL;
			Node* temp = headBucket;
			while (temp != NULL) {
				if (strcmp(temp->key, key) == 0) {
					if (prev == NULL) {
						buckets[bucketIndex] = temp->next;
					} else {
						prev->next = temp->next;
					}
					temp->next = NULL;
					delete temp;
					count--;
					return;
				}
				prev = temp;
				temp = temp->next;
			}
		}

		int get_value(char* key) {
			int bucketIndex = hash(key);
			Node* headBucket = buckets[bucketIndex];
			Node* temp = headBucket;
			while (temp != NULL) {
				if (strcmp(temp->key, key) == 0) {
					return temp->value;
				}
				temp = temp->next;
			}
			return -1;
		}

		void insert(char* key, int value) {
			int bucketIndex = hash(key);
			Node* headBucket = buckets[bucketIndex];
			Node* temp = headBucket;
			while (temp != NULL) {
				if (strcmp(temp->key, key) == 0) {
					temp->value = value;
					return;
				}
				temp = temp->next;
			}
			count++;
			Node* newNode = new Node(key, value);
			newNode->next = headBucket;
			buckets[bucketIndex] = newNode;
			if ((count*1.0)/tablesize > 0.75) {
				rehash();
			}
		}


		int num_elements() {
			return count;
		}

		bool is_empty() {
			return count == 0;
		}

};
#endif
