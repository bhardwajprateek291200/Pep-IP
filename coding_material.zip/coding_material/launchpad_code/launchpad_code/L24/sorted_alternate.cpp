#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

int count(vector<int>* first, vector<int>* second) {
	int empty = 1;
	int endingWithFirst = 0;
	int endingWithSecond = 0;
	int i = 0;
	int j = 0;
	while (i < first->size() && j < second->size()) {
		if (first->at(i) < second->at(j)) {
			endingWithFirst += empty + endingWithSecond;
			i++;
		} else {
			endingWithSecond += empty + endingWithFirst;
			j++;
		}
	}
	while (i < first->size()) {
		endingWithFirst += empty + endingWithSecond;
		i++;
	}

	while (j < second->size()) {
		endingWithSecond += empty + endingWithFirst;
		j++;
	}
	cout << empty + endingWithFirst + endingWithSecond << endl;
	return empty + endingWithFirst + endingWithSecond;
}

vector<vector<int>*>* getALLComb(vector<int>* first, vector<int>* second) {
	vector<vector<int>*> * output = new vector<vector<int>*>();
	vector<int>* empty = new vector<int>();
	output->push_back(empty);
	unordered_map<vector<int>*, int> lastElementArray;
	lastElementArray[empty] = 0;

	int i = 0;
	int j = 0;
	while (i < first->size() && j < second->size()) {
		if (first->at(i) < second->at(j)) {
			for (int k = 0; k < output->size(); k++) {
				vector<int>* v = output->at(k);
				if (lastElementArray[v] != 1) {
					vector<int>* newVector = new vector<int>(*v);
					newVector->push_back(first->at(i));
					output->push_back(newVector);
					lastElementArray[newVector] = 1;
				}
			}
			i++;
		} else {
			for (int k = 0; k < output->size(); k++) {
				vector<int>* v = output->at(k);
				if (lastElementArray[v] != 2) {
					vector<int>* newVector = new vector<int>(*v);
					newVector->push_back(second->at(j));
					output->push_back(newVector);
					lastElementArray[newVector] = 2;
				}
			}
			j++;
		}
	}

	while (i < first->size()) {
		for (int k = 0; k < output->size(); k++) {
			vector<int>* v = output->at(k);
			if (lastElementArray[v] != 1) {
				vector<int>* newVector = new vector<int>(*v);
				newVector->push_back(first->at(i));
				output->push_back(newVector);				
				lastElementArray[newVector] = 1;
			}

		}
		i++;
	}

	while (j < second->size()) {
		for (int k = 0; k < output->size(); k++) {
			vector<int>* v = output->at(k);
			if (lastElementArray[v] != 2) {
				vector<int>* newVector = new vector<int>(*v);
				newVector->push_back(second->at(j));
				output->push_back(newVector);
				lastElementArray[newVector] = 2;
			}
		}
		j++;
	}
	return output;
}

int main() {
	vector<int> first;
	first.push_back(1);
	first.push_back(3);
	first.push_back(5);
	first.push_back(7);

	vector<int> second;
	second.push_back(2);
	second.push_back(4);
	second.push_back(6);
	second.push_back(8);

	count(&first, &second);

	vector<vector<int>*>* output = getALLComb(&first, &second);
	cout << output->size();
	for (int i = 0; i < output->size(); i++) {
		cout << endl;
		for (int j = 0; j < output->at(i)->size(); j++) {
			cout << output->at(i)->at(j) << " ";
		}
		delete output->at(i);
	}
	delete output;
}