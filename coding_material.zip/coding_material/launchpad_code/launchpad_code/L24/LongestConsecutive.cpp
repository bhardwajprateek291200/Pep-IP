#include <iostream>
#include <unordered_map>
using namespace std;

pair<int, int>* getLongestConsecutive(int* input, int size) {
	unordered_map<int, bool> map;
	for (int i = 0; i < size; i++) {
		map[input[i]] = true;
	}
	int bestLengthSoFar = 0;
	int bestStart = 0;
	for (int i = 0; i < size; i++) {
		if (!map[input[i]])
			continue;

		int start = input[i];
		while (map[start] == true) {
			map[start] = false;
			start--;
		}
		start++;

		int end = input[i] + 1;
		while (map[end]) {
			map[end] = false;
			end++;
		}
		end--;
		int currentLength = end - start + 1;
		if (currentLength > bestLengthSoFar) {
			bestStart = start;
			bestLengthSoFar = currentLength;
		}
	}
	cout << bestStart << " " << bestLengthSoFar << endl;
	pair<int, int>* p = new pair<int, int>(bestStart, bestLengthSoFar);
	return p;
}

int main() {
	int a[] = {2, 12, 9, 16, 10, 5, 3, 20, 25, 11, 1, 8, 6};
	getLongestConsecutive(a, 13);
}

