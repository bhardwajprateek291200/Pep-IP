#ifndef TRIE_H
#define TRIE_H
#include "TrieNode.h"
class Trie {
	TrieNode* root;
	int numWords;

	static void remove(TrieNode* node, char* word) {
		if (word[0] == '\0') {
			node->is_terminal = false;
			return;
		}
		TrieNode* child = node->getChild(word[0]);
		remove(child, word + 1);
		if (!child->is_terminal && child->numChild() == 0) {
			node->removeChild(word[0]);
			delete child;
		}
	}

	public:
		Trie() {
			numWords = 0;
			root = new TrieNode('\0');
		}

		~Trie() {
			delete root;
		}

		int size() {
			return numWords;
		}

		bool is_empty() {
			return size() == 0;
		}

		void remove(char* word) {
			if (!find(word)) {
				return;
			}
			remove(root, word);
			numWords--;
		}

		void insert(char* word) {
			if (find(word)) {
				return;
			}
			TrieNode* temp = root;
			for (int i = 0; word[i] != '\0'; i++) {
				TrieNode* child = temp->getChild(word[i]);
				if (child == NULL) {
					child = new TrieNode(word[i]);
					temp->addChild(word[i], child);
				}
				temp = child;
			}
			temp->is_terminal = true;
			numWords++;
		}

		bool find(char* word) {
			TrieNode* temp = root;
			for (int i = 0; word[i] != '\0'; i++) {
				TrieNode* child = temp->getChild(word[i]);
				if (child == NULL) {
					return false;
				}
				temp = child;
			}
			return temp->is_terminal;
		}
};
#endif
