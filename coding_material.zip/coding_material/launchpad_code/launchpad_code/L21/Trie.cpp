#include <iostream>
#include "Trie.h"
using namespace std;

int main() {
	Trie t;
	char a[] = "new";
	t.insert(a);
	t.insert("news");
	t.insert("done");
	t.insert("don");
	cout << " " << t.size() << endl;
	t.insert("done");
	cout << " " << t.size() << endl;
	cout << t.find("done") << endl;
	cout << t.find("one") << endl;
	cout << t.find("don") << endl;
	t.remove("don");
	cout << t.find("don") << endl;
	cout << t.find("done") << endl;
}

