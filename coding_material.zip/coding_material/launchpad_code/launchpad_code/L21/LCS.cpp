#include <iostream>
using namespace std;

long fibO[1000];

long fibI(int n ) {
	long* arr = new long[n+1];
	arr[0] = 0;
	arr[1] = 1;
	for (int i = 2; i <= n; i++) {
		arr[i] = arr[i-1] + arr[i - 2];
	}
	long temp = arr[n];
	delete [] arr;
	return temp;
}

long fibB(int n ) {
	if (n == 0)
		return 0;
	if (n == 1)
		return 1;

	if (fibO[n] > 0) {
		return fibO[n];
	}

	fibO[n] = fibB(n - 1) + fibB(n - 2);
	return  fibO[n];
}

long fib(int n ) {
	if (n == 0)
		return 0;
	if (n == 1)
		return 1;
	return fib(n - 1) + fib(n - 2);
}

int lcsI(char* s1, char*s2) {
	int m = strlen(s1);
	int n = strlen(s2);
	// dp[i][j] == lcs of last i chars of s1 and last j chars of s2	
	int** dp = new int*[m + 1];
	for (int i = 0; i <= m; i++) {
		dp[i] = new int[n + 1];
	}

	for (int i = 0; i <= m; i++) {
		dp[i][0] = 0;
	}
	
	for (int j = 0; j <= n; j++) {
		dp[0][j] = 0;
	}

	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= n; j++) {
			if (s1[m - i] == s2[n - j]) {
				dp[i][j] = 1 + dp[i-1][j-1];
			} else {
				dp[i][j] = max(dp[i-1][j], dp[i][j-1]);
			}
		}
	}
	int ans = dp[m][n];
	for (int i = 0; i <= m; i++) {
		delete [] dp[i];
	}
	delete [] dp;
	return ans;
}

int lcsB(char* s1, char* s2, int** dp) {
	if (s1[0] == '\0' || s2[0] == '\0') {
		return 0;
	}

	int m = strlen(s1);
	int n = strlen(s2);

	if (dp[m][n] >= 0) {
		return dp[m][n];
	}
	if (s1[0] == s2[0]) {
		dp[m][n]  = 1 + lcsB(s1 + 1, s2 + 1, dp);
		return dp[m][n];
	}
	int option1 = lcsB(s1, s2 + 1, dp);
	int option2 = lcsB(s1 + 1, s2, dp);
	dp[m][n]  = max(option1, option2);
	return dp[m][n];
}

int lcs(char* s1, char* s2) {
	if (s1[0] == '\0' || s2[0] == '\0') {
		return 0;
	}

	if (s1[0] == s2[0])
		return 1 + lcs(s1 + 1, s2 + 1);

	int option1 = lcs(s1, s2 + 1);
	int option2 = lcs(s1 + 1, s2);
	return max(option1, option2);
}

int main() {
	for (int i = 0; i < 1000; i++) {
		fibO[i] = 0;
	}

	cout << "calling Better" << fibB(50) << endl;
	//cout << "calling other" << fib(50) << endl;
	char a[] = "abcdaudihidhidhsihsihishishishihfibufbjbkhsugdgudgu    gdugudhudh";
	char b[] = "jishihifhishigyrybsihidgugdugidgigdgdggib12c3ab4c7d";
	int** out = new int*[100];
	for (int i = 0; i < 100; i++) 
		out[i] = new int[100];

	for (int i = 0; i < 100; i++) {
		for (int j = 0; j < 100; j++)
			out[i][j] = -1;
	}

	int n = lcsB(a,b,out);
	cout << n;
	for (int i = 0; i < 100; i++) 
		delete [] out[i];
	delete [] out;
}

