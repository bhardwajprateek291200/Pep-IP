#include <iostream>
using namespace std;

int mm(int* input, int s, int e) {
	if (s >= e-1)
		return 0;

	int best_option = -1;
	for (int k = s + 1; k < e; k++) {
		int option = mm(input, s, k) + mm(input, k, e) + input[s]*input[k]*input[e];
		if (best_option == -1 || option < best_option)
			best_option = option;
	}
	return best_option;
}

int main() {
	int a[] = {10,30,5,60};
	cout << mm(a, 0, 3) << endl;
}

