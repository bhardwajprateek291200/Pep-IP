#ifndef TRIENODE_H
#define TRIENODE_H
#include <unordered_map>
using namespace std;
class TrieNode {
	char data;
	unordered_map<char, TrieNode*> children;

	public:
	  bool is_terminal;
		TrieNode(char data) {
			this->data = data;
			is_terminal = false;
		}

		~TrieNode() {
			unordered_map<char, TrieNode*>::iterator it;
			it = children.begin();
			while (it != children.end()) {
				cout << data << ":" << it->first << ":" << it->second << endl;
				delete it->second;
				it++;
			}	
		}

		int numChild() {
			return children.size();
		}

		void removeChild(char childChar) {
			children.erase(childChar);
		}

		void addChild(char childChar, TrieNode* child) {
			children[childChar] = child;
		}

		TrieNode* getChild(char childChar) {
			if (children.count(childChar) == 0)
				return NULL;
			return children.at(childChar);
		}

		char getData() {
			return data;
		}
};
#endif
