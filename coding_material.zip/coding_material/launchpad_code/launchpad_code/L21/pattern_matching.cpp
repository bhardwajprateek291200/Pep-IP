#include <iostream>
#include <unordered_map>
using namespace std;

int brute_force(char* s, char* t) {
	int m = strlen(s);
	int n = strlen(t);

	for (int i = 0; i <= m-n; i++) {
		int j = 0;
		for (; j <n; j++) {
			if (s[i + j] != t[j]) {
				break;
			}
		}
		if (j == n) {
			return i;
		}
	}
	return -1;
}

void last_index_map(char* t, unordered_map<char, int> &lastIndex) {
	for (int i = 0; t[i] != '\0'; i++) {
		lastIndex[t[i]] = i + 1;
	}
}

int boyer_moore(char* s, char* t) {
	int m = strlen(s);
	int n = strlen(t);
	unordered_map<char, int> lastIndex;
	last_index_map(t, lastIndex);

	for (int i = 0; i <= m-n;) {
		int j = n -1;
		for (; j>=0; j--) {
			if (s[i+j] != t[j]) {
				// increment i
				int lastIndexChar = lastIndex[s[i+j]] - 1;
				if (lastIndexChar == -1) {
					i = i + j + 1;
				} else if (lastIndexChar > j) {
					i++;
				} else {
					i = i + j - lastIndexChar;
				}
				break;
			}
		}
		if (j == -1) {
			return i;
		}
	}
	return -1;
}

int main() {
	char a[] = "this is a test string";
	char b[] = "test";
	cout << brute_force(a,b) << endl;
	cout << boyer_moore(a,b) << endl;
}

