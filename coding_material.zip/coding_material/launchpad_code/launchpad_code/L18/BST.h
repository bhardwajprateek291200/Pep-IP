#include <iostream>
#include "BinaryTreeNode.h"
using namespace std;

class BST {
	int size;
	BinaryTreeNode* root;

	static bool find(BinaryTreeNode* currentRoot, int element) {
			if (currentRoot == NULL)
				return false;
			if (currentRoot->data == element)
				return true;
			else if (currentRoot->data > element) {
				return find(currentRoot->left, element);
			} else {
				return find(currentRoot->right, element);
			}
	}

	static void remove(BinaryTreeNode* &root, int element) {
		if (root == NULL) {
			return;
		}

		if (root->data == element) {
			if (root->left == NULL && root->right == NULL) {
				delete root;
				root = NULL;
				return;
			} else if (root->left == NULL) {
				BinaryTreeNode* temp = root->right;
				root->left = NULL;
				root->right = NULL;
				delete root;
				root = temp;
				return;
			} else if (root->right == NULL) {
				BinaryTreeNode* temp = root->left;
				root->left = NULL;
				root->right = NULL;
				delete root;
				root = temp;
				return;
			} else {
				BinaryTreeNode* leftMax = root->left;
				while (leftMax->right != NULL) {
					leftMax = leftMax->right;
				}
				root->data = leftMax->data;
				remove(root->left, leftMax->data);
			}
		 } else if (root->data > element) {
				remove(root->left, element);
		 } else {
				remove(root->right, element);
		 }

	}

	static void insert(BinaryTreeNode* &root, int element) {
		if (root == NULL) {
			root = new BinaryTreeNode(element);
			return;
		}

		if (root->data >= element) {
			insert(root->left, element);
			return;
		} else {
			insert(root->right, element);
		}
	}

	static void print(BinaryTreeNode* root) {
		if (root == NULL) 
			return;
	
		print(root->left);
		cout << root->data << " ";
		print(root->right);
	}
	public:
		BST() {
			size = 0;
			root = NULL;
		}

		void remove(int element) {
			if (!find(element)) {
				return;
			}
			remove(root, element);
		}

		void insert(int element) {
			insert(root, element);
		}

		void print() {
			print(root);
			cout << endl;
		}

		bool find(int element) {
			return find(root, element);
		}

		int get_size() {
			return size;
		}

		bool is_empty() {
			return size == 0;
		}


};

