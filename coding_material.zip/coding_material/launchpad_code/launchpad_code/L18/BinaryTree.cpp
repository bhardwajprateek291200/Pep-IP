#include <iostream>
#include "BinaryTreeNode.h"
#include "Node.h"
#include "Queue.h"
#include <queue>
#include <vector>
using namespace std;

vector<BinaryTreeNode*>* findPath(BinaryTreeNode* root, int element) {
	if (root == NULL) {
		return NULL;
	}

	if (root->data == element) {
		vector<BinaryTreeNode*> * output = new vector<BinaryTreeNode*>();
		output->push_back(root);
		return output;
	}

	vector<BinaryTreeNode*> *leftO = findPath(root->left, element);
	if (leftO != NULL) {
		leftO->push_back(root);
		return leftO;
	}
	
	vector<BinaryTreeNode*> *rightO = findPath(root->right, element);
	if (rightO) {
		rightO->push_back(root);
		return rightO;
	}
	return NULL;
}

BinaryTreeNode* takeInput() {
	cout << "Enter root data " << endl;
	int root_data;
	cin >> root_data;

	BinaryTreeNode* root = new BinaryTreeNode(root_data);
	Queue<BinaryTreeNode*> q;
	q.enqueue(root);

	while (!q.is_empty()) {
		BinaryTreeNode* current_node = q.dequeue();
		int left_child;
		cout << "Enter left child data for ";
		cout << current_node->data << endl;
		cin >> left_child;
		if (left_child != -1) {
			BinaryTreeNode* left = new BinaryTreeNode(left_child);
			current_node->left = left;
			q.enqueue(left);
		}	

		int right_child;
		cout << "Enter right child for ";
		cout << current_node->data << endl;
		cin >> right_child;
		if (right_child != -1) {
			BinaryTreeNode* right = new BinaryTreeNode(right_child);
			current_node->right = right;
			q.enqueue(right);
		}
	}
	return root;	
}

void preorder(BinaryTreeNode* root) {
	if (root == NULL) {
		return;
	}
	cout << root->data << " " << endl;
	preorder(root->left);
	preorder(root->right);
}

vector<Node*> level_wise_ll(BinaryTreeNode* root) {	
	vector<Node*> output;
	queue<BinaryTreeNode*> q;
	q.push(root);
	Node* currentHead = NULL;
	Node* currentTail = NULL;
	int current_level_count = 1;
	int next_level_count = 0;
	while (!q.empty()) {
		BinaryTreeNode* currentNode = q.front();
		q.pop();

		Node* newNode = new Node(currentNode->data);

		if (currentHead == NULL) {
			currentHead = newNode;
			currentTail = newNode;
		} else {
			currentTail->next = newNode;
			currentTail = newNode;
		}
		if (currentNode->left != NULL) {
			q.push(currentNode->left);
			next_level_count++;
		}	
		
		if (currentNode->right != NULL) {
			q.push(currentNode->right);
			next_level_count++;
		}
 	
		current_level_count--;
		if (current_level_count == 0) {

			output.push_back(currentHead);
			currentHead = NULL;
			currentTail = NULL;
			current_level_count = next_level_count;
			next_level_count = 0;
		}
	 }
	return output;
}
void level_wise(BinaryTreeNode* root) {	
	queue<BinaryTreeNode*> q;
	q.push(root);
	int current_level_count = 1;
	int next_level_count = 0;
	while (!q.empty()) {
		BinaryTreeNode* currentNode = q.front();
		q.pop();
		cout << currentNode->data;
		if (currentNode->left != NULL) {
			q.push(currentNode->left);
			next_level_count++;
		}	
		
		if (currentNode->right != NULL) {
			q.push(currentNode->right);
			next_level_count++;
		}
 	
		current_level_count--;
		if (current_level_count == 0) {
			cout << endl;
			current_level_count = next_level_count;
			next_level_count = 0;
		}
	 }

}

BinaryTreeNode* buildTree(int* pre, int *in, int pres,
		int pree, int ins, int ine) {
	if (pres > pree) {
		return NULL;
	}

	int root = pre[pres];
	int i = ins;
	while (i <= ine) {
		if (root == in[i])
			break;
		i++;
	}

	int leftTreeSize = i - ins;
	int rightTreeSize = ine - i;
	
	int inLeftS = ins;
	int inLeftE = i - 1;
	int inRightS = i + 1;
	int inRightE = ine;

	int preLeftS = pres + 1;
	int preLeftE = preLeftS + leftTreeSize -1;
	int preRightS = preLeftE + 1;
	int preRightE = pree;
	BinaryTreeNode* rootNode = new BinaryTreeNode(root);
	BinaryTreeNode* left = buildTree(pre, in, preLeftS, preLeftE, inLeftS, inLeftE);
	BinaryTreeNode* right = buildTree(pre, in, preRightS, preRightE, inRightS, inRightE);
	rootNode->left = left;
	rootNode->right = right;
	return rootNode;
}

BinaryTreeNode* removeLeaves(BinaryTreeNode* root) {
	if (root == NULL)
		return NULL;
	if (root->left == NULL && root->right == NULL) {
		delete root;
		return NULL;
	}
	root->right = removeLeaves(root->right);
	root->left = removeLeaves(root->left);
	return root;
}

bool isBalanced(BinaryTreeNode* root, int &height) {
	if (root == NULL) {
		height = 0;
		return true;
	}
	int rh, lh;
	bool leftB = isBalanced(root->left, lh);
	bool rightB = isBalanced(root->right, rh);
	height = max(rh, lh) + 1;
	if (lh - rh > 1 || rh - lh > 1) {
		return false;
	}

	return leftB && rightB;
}


int main() {
	BinaryTreeNode* root = takeInput();
	preorder(root);
	level_wise(root);
	vector<Node*> output = level_wise_ll(root);
	cout << "printing lls" << endl;
	for (int i = 0; i < output.size(); i++) {
		Node* head = output[i];
		Node* temp = head;
		while (head != NULL) {
			cout << head->data << "-->";
			head = head->next;
		}
		cout << endl;
		delete temp;
	 }
	delete root;
}






