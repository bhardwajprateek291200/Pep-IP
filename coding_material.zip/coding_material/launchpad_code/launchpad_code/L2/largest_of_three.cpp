#include <iostream>
using namespace std;

int main() {
	int a, b, c;

	cin >> a >> b >> c;

	if (a > b && a > c) {
		cout << a << "\n";
	}

	if (b > a && b > c) {
		cout << b << "\n";
	}
  if (c > a && c > b) {
		cout << c << "\n";
	}
}
