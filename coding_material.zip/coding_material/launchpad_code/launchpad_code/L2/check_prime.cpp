#include <iostream>
using namespace std;

int main() {
	int n = 20;
	int i = 1;
	while (i <= n) {
		if (i == 2) {
			i++;
			continue;
		}
		if (i == 5) {
			break;
		}
		cout << i << " hey" << endl;
		i++;
	}
	cout << "done";
}
