#include <iostream>
using namespace std;

int main() {
	int p;
	int r;
	int t;

	cout << "Enter the amount\n";
	cin >> p;

	cout << "Enter rate of interest\n";
	cin >> r;

	cout << "Enter duration\n";
	cin >> t;

	int interest = p*r*t/100;
	cout << "Interest is: " << interest;

}
