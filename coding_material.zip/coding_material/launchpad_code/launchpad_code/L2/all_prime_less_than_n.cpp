#include <iostream>
using namespace std;

int main() {
	int n;
	cin >> n;
	// Current number is the next number to be checked for primality
	int current_number = 2;

	while (current_number <= n) {

		int d = 2;
		int prime = 1;
		while (d < current_number) {
			if (current_number % d == 0) {
				prime = 0;
				break;
			}
			d++;
		}
		if (prime == 1) {
			cout << current_number << " is prime\n";
		}
		current_number++;
	}
}

