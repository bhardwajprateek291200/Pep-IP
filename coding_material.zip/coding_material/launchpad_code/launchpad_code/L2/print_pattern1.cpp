#include <iostream>
using namespace std;

int main() {
	int num_rows;
	cin >> num_rows;
	
	int current_row = 1;

	while (current_row <= num_rows) {
		int spaces_so_far = 0;
		while (spaces_so_far < num_rows - current_row) {
			cout << ' ';
			spaces_so_far++;
		}

		int next_number = 1;

		while (next_number <= 2*current_row - 1) {
			cout << next_number;
			next_number++;
		}
		cout << '\n';
		current_row++;
	}

}
