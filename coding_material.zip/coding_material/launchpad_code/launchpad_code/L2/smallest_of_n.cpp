#include <iostream>
using namespace std;

int main() {
	int n;
	cin >> n;

	int min = 10000;
	int i = 1;

	while (i <= n) {
		cout << "Enter " << i << "th Number\n";
		int num;
		cin >> num;
		if (num < min) {
			min = num;
		}
		i++;
	}
	cout << "smallest number is " << min << "\n";
}
