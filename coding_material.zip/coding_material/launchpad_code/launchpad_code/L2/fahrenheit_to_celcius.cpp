#include <iostream>
#define LIMIT 300
using namespace std;

int main() {

	int f = 0;

	while (f <= LIMIT) {
		int c = (f - 32)*(5.0/9);
		cout << f << '\t' << c << "\n";
		f = f + 20;
	}

}
