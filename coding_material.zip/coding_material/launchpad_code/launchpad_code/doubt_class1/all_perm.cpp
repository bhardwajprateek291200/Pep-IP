#include <iostream>
#include <cstring>

using namespace std;

void printperm(char input[], char sofar[]) {
	if (input[0] == '\0') {
		cout << sofar << endl;
		return;
	}
	int sofarlength = strlen(sofar);	
	for (int i = 0; input[i] != '\0'; i++) {
		char smallerInput[100];
		for(int j = 0; j < i; j++) {
			smallerInput[j] = input[j];
		}
		int j = i + 1;
		for (; input[j] != '\0'; j++) {
			smallerInput[j - 1] = input[j];
		}
		smallerInput[j - 1] = '\0';
		sofar[sofarlength] = input[i];
		sofar[sofarlength + 1] = '\0';
		printperm(smallerInput, sofar);
	}
 
}

int all_perm(char input[], char output[][100]) {
	if (input[0] == '\0') {
		output[0][0] = '\0';
		return 1;
	}
  int outputRows = 0;
	for (int i = 0; input[i] != '\0'; i++) {
		char smallerInput[100];
		for(int j = 0; j < i; j++) {
			smallerInput[j] = input[j];
		}
		int j = i + 1;
		for (; input[j] != '\0'; j++) {
			smallerInput[j - 1] = input[j];
		}
		smallerInput[j - 1] = '\0';
		char smallerOutput[1000][100];
		int rows = all_perm(smallerInput, smallerOutput);
		int currentRow = 0;
		while (currentRow < rows) {
			int currentCol = 0;
			output[outputRows][0] = input[i];
			for (;smallerOutput[currentRow][currentCol] != '\0';currentCol++ ) {
				output[outputRows][currentCol + 1] = 
					smallerOutput[currentRow][currentCol];				
			}
			output[outputRows][currentCol + 1] = '\0';
			currentRow++;
			outputRows++;
		}
	}
	return outputRows;

}


int main() {
	char input[100];
	cin >> input;
	char output1[100];
	output1[0] = '\0';
	printperm(input, output1);
	char output[1000][100];
/*	int rows = all_perm(input, output);
	for (int i = 0; i < rows; i++) {
		cout << output[i] << endl;
	}
	*/
}

