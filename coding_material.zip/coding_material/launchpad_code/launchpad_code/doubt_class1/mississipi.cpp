#include<iostream>
using namespace std;

/*int length(char arr[]){
	int i=0;
	while(arr[i]!='\0')
}*/

void mississipi(char arr[]){
	int gs=0, gl=0, change=0;
	int cs=0, cl=1;
	char a=0, b=0;
	a = arr[0];

	for(int i=1; arr[i-1]!='\0'; i++){
		if(arr[i]!=a && b==0){
			b=arr[i];
			change=i;
		}

		if(arr[i]==a || arr[i]==b){
			cl++;
		}
		else{
			if(cl > gl){
				gl=cl;
				gs=cs;
			}
			cs=change;
			cl=i-change+1;
			if(arr[change]==a) b = arr[i];
			else a = arr[i];
		}
		if(arr[i]!=arr[i-1]) change=i;
	}

	for(int i = 0; i<gl; i++){
		cout<<arr[gs + i];
	}
}

int main(){
	char arr[25];
	cin.getline(arr, 25);
	mississipi(arr);
}