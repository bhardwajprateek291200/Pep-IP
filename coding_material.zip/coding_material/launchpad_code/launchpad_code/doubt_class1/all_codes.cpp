#include <iostream>
using namespace std;

char getCorrespondingChar(int i) {
	return 'a' + i - 1;
}

int all_codes(int n, char output[][100]) {
	if (n == 0) {
		output[0][0] = '\0';
		return 1;
	}
	
	char smallerOutput1[1000][100];
	int rows1 = all_codes(n/10, smallerOutput1);
	char lastDigitChar = getCorrespondingChar(n % 10);
	
	int k = 0;
	while (k < rows1) {
		int i = 0;
		for (; smallerOutput1[k][i] != '\0'; i++) {
			output[k][i] = smallerOutput1[k][i];
		}
		output[k][i] = lastDigitChar;
		output[k][i+1] = '\0';
		k++;
	}
	
	int lastTwoDigit = n % 100;
	if (lastTwoDigit <= 26 && lastTwoDigit >=10) {
		int rows2 = all_codes(n/100, smallerOutput1);
		char lastTwoDigitChar = getCorrespondingChar(lastTwoDigit);
		int j = 0;
		while (j < rows2) {
			int i = 0;
			for (; smallerOutput1[j][i] != '\0'; i++) {
				output[k][i] = smallerOutput1[j][i];
			}
			output[k][i] = lastTwoDigitChar;
			output[k][i+1] = '\0';
			k++;
			j++;
		}
	}
	return k;
}

int main() {
	int n;
	cin >> n;
	char output[1000][100];
	int rows = all_codes(n, output);
	for (int i = 0; i < rows; i++) {
		cout << output[i] << endl;
	}
}

