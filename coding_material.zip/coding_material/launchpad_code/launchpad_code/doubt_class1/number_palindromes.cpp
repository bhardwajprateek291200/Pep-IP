#include <iostream>
using namespace std;

int num_pal(char n[]) {
	int count = 1;

	for (int i = 0; n[i] != '\0'; i++) {
		int j = 0;
		while (i -j >= 0 && n[i + j] != '\0' && n[i-j] == n[i+j]) {
			j++;
			count++;
		}
	}

	for (int i = 0; n[i] != '\0'; i++) {
		int j = 0;
		while (i -j + 1 >= 0 
				&& n[i + j] != '\0' 
				&& n[i-j+1] == n[i+j]) {
			j++;
			count++;
		}
	}
	return count;
}

int main() {
	char n[200];
	cin >> n;
	int count  = num_pal(n);
	cout << count;
}
