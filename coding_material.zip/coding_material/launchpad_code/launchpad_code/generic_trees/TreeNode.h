class TreeNode {
	public:
		int data;
		TreeNode** children;
		int children_count;
	
	TreeNode(int data, int num_children) {
		this->data = data;
		this->children_count = num_children;
		children = new TreeNode*[num_children];
	}

	~TreeNode() {
		for (int i = 0; i < children_count; i++) {
			delete children[i];
		}
		delete [] children;
	}	

};
