#include <iostream>
#include "PriorityQueue.h"
using namespace std;

int* findKMax(int* input, int size, int k) {
	PriorityQueue<int> p;

	for (int i = 0; i < k; i++) {
		p.insert(input[i], input[i]);
	}

	for (int i = k; i < size; i++) {
		int* minAmongMaxSoFar = p.min();
		if (input[i] > *(minAmongMaxSoFar)) {
			p.removeMin();
			p.insert(input[i], input[i]);
		}
	}
	
	int* output = new int[k];
	for (int i = 0; i < k; i++) {
		output[i] = *(p.min());
		p.removeMin();
	}
	return output;
}

int main() {
	PriorityQueue<int> p;

	int a[] = {10,9,8,70,6,5,4,13,2,1};
	int* output=findKMax(a, 10, 4);
	cout << endl;
	for (int i = 0; i < 4; i++) {
		cout << output[i] << " ";
	}
	return 0;
	for (int i = 0; i < 10; i++) {
		p.insert(a[i], a[i]);
	}

	while (!p.is_empty()) {
		int* min = p.min();
		cout << *min << endl;
		p.removeMin();
	}

}
