class Triplet {
	public:
	int min;
	int max;
	bool isBST;

	Triplet(int min, int max, bool isBST) {
		this->min = min;
		this->max = max;
		this->isBST = isBST;
	}

};
