#include <iostream>
#include "BinaryTreeNode.h"
#include "Node.h"
#include "Queue.h"
#include <queue>
#include <stack>
using namespace std;

BinaryTreeNode* takeInput() {
	cout << "Enter root data " << endl;
	int root_data;
	cin >> root_data;

	BinaryTreeNode* root = new BinaryTreeNode(root_data);
	Queue<BinaryTreeNode*> q;
	q.enqueue(root);

	while (!q.is_empty()) {
		BinaryTreeNode* current_node = q.dequeue();
		int left_child;
		cout << "Enter left child data for ";
		cout << current_node->data << endl;
		cin >> left_child;
		if (left_child != -1) {
			BinaryTreeNode* left = new BinaryTreeNode(left_child);
			current_node->left = left;
			q.enqueue(left);
		}	

		int right_child;
		cout << "Enter right child for ";
		cout << current_node->data << endl;
		cin >> right_child;
		if (right_child != -1) {
			BinaryTreeNode* right = new BinaryTreeNode(right_child);
			current_node->right = right;
			q.enqueue(right);
		}
	}
	return root;	
}

void preorder(BinaryTreeNode* root) {
	if (root == NULL) {
		return;
	}
	cout << root->data << " " << endl;
	preorder(root->left);
	preorder(root->right);
}

vector<Node*> level_wise_ll(BinaryTreeNode* root) {	
	vector<Node*> output;
	queue<BinaryTreeNode*> q;
	q.push(root);
	Node* currentHead = NULL;
	Node* currentTail = NULL;
	int current_level_count = 1;
	int next_level_count = 0;
	while (!q.empty()) {
		BinaryTreeNode* currentNode = q.front();
		q.pop();

		Node* newNode = new Node(currentNode->data);

		if (currentHead == NULL) {
			currentHead = newNode;
			currentTail = newNode;
		} else {
			currentTail->next = newNode;
			currentTail = newNode;
		}
		if (currentNode->left != NULL) {
			q.push(currentNode->left);
			next_level_count++;
		}	
		
		if (currentNode->right != NULL) {
			q.push(currentNode->right);
			next_level_count++;
		}
 	
		current_level_count--;
		if (current_level_count == 0) {

			output.push_back(currentHead);
			currentHead = NULL;
			currentTail = NULL;
			current_level_count = next_level_count;
			next_level_count = 0;
		}
	 }
	return output;
}
void level_wise(BinaryTreeNode* root) {	
	queue<BinaryTreeNode*> q;
	q.push(root);
	int current_level_count = 1;
	int next_level_count = 0;
	while (!q.empty()) {
		BinaryTreeNode* currentNode = q.front();
		q.pop();
		cout << currentNode->data;
		if (currentNode->left != NULL) {
			q.push(currentNode->left);
			next_level_count++;
		}	
		
		if (currentNode->right != NULL) {
			q.push(currentNode->right);
			next_level_count++;
		}
 	
		current_level_count--;
		if (current_level_count == 0) {
			cout << endl;
			current_level_count = next_level_count;
			next_level_count = 0;
		}
	 }

}

vector<BinaryTreeNode*>* findpath(BinaryTreeNode* root, int data) {
	if (root == NULL)
		return NULL;

	if (root->data == data) {
		vector<BinaryTreeNode*> * v = new vector<BinaryTreeNode*>();
		v->push_back(root);
		return v;
	}

	vector<BinaryTreeNode*> * leftAns = findpath(root->left, data);
	if (leftAns != NULL) {
		leftAns->push_back(root);
		return leftAns;
	}

	vector<BinaryTreeNode*> * rightAns = findpath(root->right, data);
	if (rightAns != NULL) {
		rightAns->push_back(root);
		return rightAns;
	}
	return NULL;
}

void printAtLevelK(BinaryTreeNode* root, int k) {
	if (root == NULL)
		return;
	if (k == 0) {
		cout << root->data << endl;
		return;
	}
	printAtLevelK(root->left, k - 1);
	printAtLevelK(root->right, k - 1);
}

void printAtDistanceK(BinaryTreeNode* root, 
	BinaryTreeNode* node, int k) {

	vector<BinaryTreeNode*> * path = findpath(root, node->data);
	for (int i = path->size() - 1; i >=1; i--) {
		if (path->at(i - 1) == root->left) {
			printAtLevelK(root->right, k - (i + 1));
		} else {
			printAtLevelK(root->left, k - (i + 1));
		}
	}
	printAtLevelK(node, k);
	delete path;
}


BinaryTreeNode* lca(BinaryTreeNode* root, int f, int s) {
	if (root == NULL)
		return NULL;
	if (root->data == f || root->data == s) {
		return root;
	}

	BinaryTreeNode* leftAns = lca(root->left, f, s);
	BinaryTreeNode* rightAns = lca(root->right, f, s);
	if (leftAns && rightAns) {
		return root;
	} else if (leftAns) {
		return leftAns;
	} else {
		return rightAns;
	}
}

void inorderIter(BinaryTreeNode* root) {
	stack<BinaryTreeNode*> inorderstack;
	inorderstack.push(root);
	bool flag = true;
	while (!inorderstack.empty()) {
		BinaryTreeNode* current = inorderstack.top();
		if (flag && current->left) {
			inorderstack.push(current->left);
			flag = true;
		} else {
			inorderstack.pop();
			flag = false;
			cout << current->data << endl;
			if (current->right) {
				inorderstack.push(current->right);
				flag = true;
			}
		}
	}
}

void findPairsSumToS(BinaryTreeNode* root, int s) {
	if (root == NULL)
		return;

	stack<BinaryTreeNode*> inorderstack;
	stack<BinaryTreeNode*> revinorderstack;
	inorderstack.push(root);
	revinorderstack.push(root);

	int inorderElement = -1;
	int revInorderElement = 0;
	bool getNextInorder = true;
	bool getNextRevInorder = true;

	bool inorderFlag = true;
	bool revInorderFlag = true;

	while (true) {
		if (getNextInorder) {
			// find inorder element
			while (true) {
				BinaryTreeNode* current = inorderstack.top();
				if (inorderFlag && current->left) {
					inorderstack.push(current->left);
				} else {
					inorderstack.pop();
					inorderElement = current->data;
					inorderFlag = false;
					if (current->right) {
						inorderstack.push(current->right);
						inorderFlag = true;
					}
					break;
				}
			}

		}

		if (getNextRevInorder) {
			while (true) {
				BinaryTreeNode* current = revinorderstack.top();
				if (revInorderFlag && current->right) {
					revinorderstack.push(current->right);
				} else {
					revinorderstack.pop();
					revInorderElement = current->data;
					revInorderFlag = false;
					if (current->left) {
						revinorderstack.push(current->left);
						revInorderFlag = true;
					}
					break;
				}
			}
		}

		if (revInorderElement <= inorderElement)
			break;

		if (inorderElement + revInorderElement == s) {
			cout << inorderElement  << " " << revInorderElement << endl;
			getNextInorder = true;
			getNextRevInorder = true;
		} else if (inorderElement + revInorderElement < s) {
			// next in inorder
			getNextInorder = true;
			getNextRevInorder = false;
		} else {
			getNextRevInorder = true;
			getNextInorder = false;
		}

	}

}


int main() {
	BinaryTreeNode* root = takeInput();
	//preorder(root);
	level_wise(root);
	findPairsSumToS(root, 8);
	// vector<Node*> output = level_wise_ll(root);
	// cout << "printing lls" << endl;
	// for (int i = 0; i < output.size(); i++) {
	// 	Node* head = output[i];
	// 	Node* temp = head;
	// 	while (head != NULL) {
	// 		cout << head->data << "-->";
	// 		head = head->next;
	// 	}
	// 	cout << endl;
	// 	delete temp;
	//  }
	delete root;
}






