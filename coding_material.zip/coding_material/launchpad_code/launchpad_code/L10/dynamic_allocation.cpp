#include <iostream>
using namespace std;

int* findAllIndices(int input[], int size) {
	if (size == 0) {
		int * output = new int[1];
		output[0] = -1;
		return output;
	}
	
	int* smallerOutput  = findAllIndices(input + 1, size - 1);
	int length = 0;
	for (int i = 0; smallerOutput[i] != -1; i++) {
		length++;
		smallerOutput[i]++;
	}
	
	if (input[0] != 7) {
		return smallerOutput;
	} else {
		int * output = new int[length + 2];
		output[0] = 0;
		for (int i = 0; i < length; i++) {
			output[i + 1] = smallerOutput[i];
		}
		output[length + 1] = -1;
		delete [] smallerOutput;
		return output;
	}
}

int main() {
	if (true) {
		int* p = new int;
		cout << p << endl;
		cout << &p << endl;
		delete p;
	}

	int n;
	cout << "Enter number of elements";
	cin >> n;
	
	int* a = new int[n];

	for (int i = 0; i < n; i++) {
		cin >> a[i];
	}

	int * output = findAllIndices(a,n);
	for (int i = 0; output[i] != -1; i++) {
		cout << output[i] << " ";
	}

	delete [] a;
	delete [] output;



}
