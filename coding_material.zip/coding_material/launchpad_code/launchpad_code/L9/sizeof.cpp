#include <iostream>
using namespace std;

void array(int a[]) {
	cout << sizeof(a) << endl;
}

int main() {
	int a[150];
	cout << sizeof(a) << endl;
	array(a);
	int i = 10;
	cout << sizeof(i) << endl;
	int* b = &a[0]; 
	cout << sizeof(b) << endl;
}

