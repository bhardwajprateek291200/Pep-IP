#include <iostream>
using namespace std;


int* pointerReturn() {
	int x= 10;
	int a[100];
	return a;
}

void increment(int& x) {
	int* y = pointerReturn();
	int b[1000];
	x++;
}

void increment(int * x) {
	int j = 10;
  x = &j;
	(*x)++;
}

int main() {
  int i = 10;
	int j = 10;
	int & k = i;

	increment(i);
	cout << i << endl;
	i++;
	j++;
	k++;
	cout << i << endl;
	cout << j << endl;
	cout << k << endl;
}

