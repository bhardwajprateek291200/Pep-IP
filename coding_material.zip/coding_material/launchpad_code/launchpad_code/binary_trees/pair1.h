#ifndef PAIR1_H
#define PAIR1_H 1
class pair1 {
	public:
	int height;
	int diameter;

	pair1(int height, int diameter) {
		this->height = height;
		this->diameter = diameter;
	}

};
#endif
