#include <iostream>
#include "BinaryTreeNode.h"
#include "Queue.h"
#include "pair1.h"
#include "pair2.h"
using namespace std;

int height(BinaryTreeNode* root) {
	if (root == NULL)
		return 0;
	return max(height(root->left), height(root->right)) + 1;
}

BinaryTreeNode* takeInput() {
	cout << "Enter root data " << endl;
	int root_data;
	cin >> root_data;

	BinaryTreeNode* root = new BinaryTreeNode(root_data);
	Queue<BinaryTreeNode*> q;
	q.enqueue(root);

	while (!q.is_empty()) {
		BinaryTreeNode* current_node = q.dequeue();
		int left_child;
		cout << "Enter left child data for ";
		cout << current_node->data << endl;
		cin >> left_child;
		if (left_child != -1) {
			BinaryTreeNode* left = new BinaryTreeNode(left_child);
			current_node->left = left;
			q.enqueue(left);
		}	

		int right_child;
		cout << "Enter right child for ";
		cout << current_node->data << endl;
		cin >> right_child;
		if (right_child != -1) {
			BinaryTreeNode* right = new BinaryTreeNode(right_child);
			current_node->right = right;
			q.enqueue(right);
		}
	}
	return root;	
}

BinaryTreeNode* just_greater(BinaryTreeNode* root, int x) {
	if (root == NULL) {
		return NULL;
	}

	BinaryTreeNode* output = NULL;
	if (root->data > x) {
		output = root;
	}

	BinaryTreeNode* left_result = just_greater(root->left, x);
	if (output == NULL) {
		output = left_result;
	} else if (left_result != NULL 
			&& left_result->data < output->data) {
		output = left_result;
	}

	BinaryTreeNode* right_result = just_greater(root->right, x);
	if (output == NULL) {
		output = right_result;
	} else if (right_result != NULL 
			&& right_result->data < output->data) {
		output = right_result;
	}
	return output;
}

pair1* diameter_height(BinaryTreeNode* root) {
	if (root == NULL) {
		pair1* output = new pair1(0,0);
		return output;
	}

	pair1* leftOutput = diameter_height(root->left);
	pair1* rightOutput = diameter_height(root->right);

	int height = max(leftOutput->height, rightOutput->height) + 1;
	int option1 = leftOutput->height + rightOutput->height;
	int option2 = leftOutput->diameter;
	int option3 = rightOutput->diameter;

	int diameter = max(option1, max(option2, option3));
	pair1* output = new pair1(height, diameter);
	return output;
	// Another option
	//return new pair1(height, diameter);
}


int diameter(BinaryTreeNode* root) {
	if (root == NULL) {
		return 0;
	}
 	int lh = height(root->left);
	int rh = height(root->right);
	int ld = diameter(root->left);
	int rd = diameter(root->right);
	return max(lh + rh, max(ld, rd));
}

void inorder(BinaryTreeNode* root) {
	if (root == NULL) {
		return;
	}
	inorder(root->left);
	cout << root->data << " " << endl;
	inorder(root->right);
}

void preorder(BinaryTreeNode* root) {
	if (root == NULL) {
		return;
	}
	cout << root->data << " " << endl;
	preorder(root->left);
	preorder(root->right);
}

int main() {
	pair<char, char> p;
	p.first = 'a';
	p.second = 'b';
	cout << p.first << endl;
	BinaryTreeNode* root = takeInput();
	preorder(root);
	cout << height(root);
	pair1* output = diameter_height(root);
	cout << output->diameter;
	delete root;
}
