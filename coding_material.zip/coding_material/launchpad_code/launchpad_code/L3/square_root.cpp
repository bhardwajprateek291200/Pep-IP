#include <iostream>
using namespace std;

int main() {
	int n;
	cout << "Enter the number\n";
	cin >> n;
	int precision;
  cout << "Enter the precision\n";
	cin >> precision;

	float answer = 0;
  float current_factor = 1;
	for (int current_precision = 0;
			current_precision <= precision;
			current_precision++) {
		for (;answer * answer <= n; answer = answer + current_factor) {
		}
	  answer = answer - current_factor;
		current_factor = current_factor/10;
	}
	cout << answer;
}
