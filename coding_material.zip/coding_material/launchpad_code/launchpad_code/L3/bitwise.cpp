#include <iostream>
using namespace std;

int main() {
	int a = 5;
	int b = 6;

	cout << (~5) << endl;
}
