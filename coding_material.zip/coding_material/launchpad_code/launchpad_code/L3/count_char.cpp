#include <iostream>
using namespace std;

int main() {
	int i = cin.get();
	int count = 0;
	while (i != '$') {
		count++;
		cout << "Enter next\n";
		i =  cin.get();
	}
	cout << "count is " << count << "\n";
}
