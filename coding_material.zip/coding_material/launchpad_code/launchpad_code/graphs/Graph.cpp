#include <iostream>
#include "Graph.h"
using namespace std;

int main() {
	graph g;
	char a[] = "Delhi";
	char b[] = "Noida";
	char c[] = "Faridabad";
	char d[] = "Gurgaon";
	g.addVertex(a);
	g.addVertex(b);
	g.addVertex(c);
	g.addVertex(d);
	g.addEdge(a,b);
	g.addEdge(d,b);
	g.addEdge(d,c);
	g.addEdge(a,c);
	//g.removeEdge(a,b);
	g.removeVertex(a);
	g.print();
}

