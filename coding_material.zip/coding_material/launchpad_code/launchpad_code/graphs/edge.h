#ifndef EDGE_H
#define EDGE_H
#include "vertex.h"
class vertex;
class edge {
	public:
		vertex* first;
		vertex* second;
		edge(vertex* f, vertex* s) {
			first = f;
			second = s;
		}

};
#endif
