#ifndef VERTEX_H
#define VERTEX_H
#include <iostream>
#include <vector>
#include "edge.h"
using namespace std;

class vertex {
	char* name;
	vector<edge*>* adjacent;

	public:

		void print() {
			cout << name << ": ";
			for (int i = 0; i < adjacent->size(); i++) {
				edge* e = adjacent->at(i);
				if (e->first == this) {
					cout << e->second->name << ",";
				} else {
					cout << e->first->name << ",";
				}
			}
			cout << endl;
		}

		vector<vertex*>* getAdjacent() {
			vector<vertex*>* output = new vector<vertex*>();
			for (int i = 0; i < adjacent->size(); i++) {
				edge* e = adjacent->at(i);
				if (e->first == this) {
					output->push_back(e->second);
				} else {
					output->push_back(e->first);
				}
			}
			return output;
		}

		void addEdge(edge* e) {
			adjacent->push_back(e);
		}

		bool isAdjacent(vertex* v) {
			for (int i = 0; i < adjacent->size(); i++) {
				edge* e = adjacent->at(i);
				if (e->first == v || e->second == v) {
					return true;
				}
			}
			return false;
		}

		void removeEdgeWith(vertex* v) {
			for (int i = 0; i < adjacent->size(); i++) {
				edge* e = adjacent->at(i);
				if (e->first == v || e->second == v) {
					adjacent->erase(adjacent->begin() + i);
					break;
				}
			}
		}

		int num_edges() {
			return adjacent->size();
		}

		char* getName() {
			char* output = new char[strlen(name) + 1];
			strcpy(output, name);
			return output;
		}

		vertex(char* v_name) {
			adjacent = new vector<edge*>();
			name = new char[strlen(v_name) + 1];
			strcpy(name, v_name);
		}

};
#endif
