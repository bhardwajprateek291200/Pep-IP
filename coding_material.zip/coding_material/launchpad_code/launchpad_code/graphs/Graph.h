#ifndef GRAPH_H
#define GRAPH_H
#include <iostream>
#include <vector>
#include "vertex.h"
using namespace std;

class graph {
	vector<vertex*>* vertices;
	
	vertex* find_vertex(char* name) {
		for (int i = 0; i < vertices->size(); i++) {
			char* vname = vertices->at(i)->getName();
			if (strcmp(name, vname) == 0) {
				delete [] vname;
				return vertices->at(i);
			}
			delete [] vname;
		}
		return NULL;
	}

	bool havePath(vertex* v, vertex* s, 
		unordered_map<vertex*, bool> &map) {
		if (v->isAdjacent(s))
			return true;

		map[v] = true;

		// unordered_map::iterator<int , int> it = map.begin();

		// while (it != map.end()) {
		// 	int key = it->first;
		// 	int value = it->second;
		// 	it++;
		// }


		vector<vertex*>* adjacent = v->getAdjacent();
		for (int i = 0; i < adjacent->size(); i++) {
			vertex* ad = adjacent->at(i);
			if (map.count(ad) != 0)
				continue;

			if (havePath(ad, s, map)) {
				return true;
			}
		}
		return false;
	}

	public:
		graph() {
			vertices = new vector<vertex*>();
		}

		int num_vertices() {
			return vertices->size();
		}

		int num_edges() {
			int count = 0;
			for (int i = 0; i < vertices->size(); i++) {
				count += vertices->at(i)->num_edges();
			}
			return count/2;
		}

		void print() {
			cout << "Num Vertices: " << num_vertices() << endl;
			cout << "Num edges: " << num_edges() << endl;
			for (int i = 0; i < vertices->size(); i++) {
				vertices->at(i)->print();
			}
		}

		void addVertex(char* vertex_name) {
			if (find_vertex(vertex_name) != NULL)
				return;

			vertex* v = new vertex(vertex_name);
			vertices->push_back(v);
		}

		void removeVertex(char* name) {
			vertex* v = find_vertex(name);
			if (v == NULL)
				return;
			int i = 0;
			for (; i < vertices->size(); i++) {
				if (vertices->at(i) == v) {
					break;
				}
			}
			vector<vertex*>* adjacent = v->getAdjacent();
			for (int i = 0; i < adjacent->size(); i++) {
				adjacent->at(i)->removeEdgeWith(v);
			}
			vertices->erase(vertices->begin() + i);
			delete v;
		}

		void removeEdge(char* first, char* second) {
			vertex* firstV = find_vertex(first); 
			vertex* secondV = find_vertex(second);

			if (firstV == NULL || secondV == NULL) {
				return;
			}
			firstV->removeEdgeWith(secondV);
			secondV->removeEdgeWith(firstV);
		}

		bool havePath(char* first, char* second) {
			vertex* v = find_vertex(first);
			vertex* s = find_vertex(second);
			if (v == NULL || s == NULL) {
				return false;
			}

			unordered_map<vertex*, bool> map;

			return havePath(v,s, map);
		}


		void addEdge(char* first, char* second) {
			vertex* firstV = find_vertex(first); 
			vertex* secondV = find_vertex(second);

			if (firstV == NULL || secondV == NULL) {
				return;
			}

			bool alreadyAdjacent = firstV->isAdjacent(secondV);
			if (alreadyAdjacent)
				return;

			edge* e = new edge(firstV, secondV);
			firstV->addEdge(e);
			secondV->addEdge(e);
		}

};
#endif
