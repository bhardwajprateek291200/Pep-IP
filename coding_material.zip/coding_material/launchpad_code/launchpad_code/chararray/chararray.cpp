#include <iostream>
using namespace std;


int strlength(char input[], int maxSize) {
	for (int i = 0; i < maxSize; i++) {
		if (input[i] == '\0') {
			return i;
		}
	}
	return -1;
}

bool isPalindrome(char input[]) {
	int length = strlength(input, 256);
	int i = 0;
	int j = length - 1;
	while (i < j) {
		if (input[i] != input[j]) {
			return false;
		}
		i++; 
		j--;
	}
	return true;
}

void substring(char input[], char dest[], int begin, int end) {
	int j = 0;
	for (int i = begin; i <= end; i++) {
		dest[j] = input[i];
		j++;
	}
	dest[j] = '\0';
}

void print_substrings(char input[]) {
	char dest[256];
	int len = strlength(input, 256);
	for (int l = 1; l <= len; l++) {
		for (int start = 0; start <= len - l; start++) {
			int end = start + l -1;
			substring(input, dest, start, end);
			cout << dest << endl;
		}
	}
}

int main() {
	char input[100];
	int i = 0;
	/*
	for (; i < n; i++) {
		input[i] = cin.get();
	}
	input[i] = '\0';
	*/
	cin >> input;
	cout << input << endl;
	cout << strlength(input, 256) << endl;
	cout << boolalpha << isPalindrome(input) << endl;

	print_substrings(input);
}
