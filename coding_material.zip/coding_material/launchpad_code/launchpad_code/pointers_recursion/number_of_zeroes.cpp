#include <iostream>
using namespace std;

int number_of_zeroes(int number) {
	if (number < 10) {
		if (number == 0) {
			return 1;
		}
		return 0;
	}

	if (number % 10 == 0) {
		return 1 + number_of_zeroes(number/10);
	} else {
		return  number_of_zeroes(number/10);
	}

}

int main() {
	cout << number_of_zeroes(22009) << endl;	
}
