#include <iostream>
using namespace std;

int strlength(char input[]) {
	if (input[0] == '\0')
		return 0;
	return 1 + strlength(input + 1);
}

int getString(int n, char output[]) {
	switch(n) {
	case 2:
		output[0] = 'a';
		output[1] = 'b';
		output[2] = 'c';
		output[3] = '\0';
		return 3;
	case 3:
		output[0] = 'd';
		output[1] = 'e';
		output[2] = 'f';
		output[3] = '\0';
		return 3; 
	case 4:
		output[0] = 'g';
		output[1] = 'h';
		output[2] = 'i';
		output[3] = '\0';
		return 3;
	}
	output[0] = '\0';
	return 0;
}
// returns number of rows in output
int keypad(int n, char output[][10]) {
	if (n == 0) {
		output[0][0] = '\0';
		return 1;
	}
	int smallOutputRows = keypad(n/10, output);
	char currentDigitArray[10];
	int length = getString(n%10, currentDigitArray);
	// Make multiple copies
	for (int k = 1; k < length; k++) {
		for (int i = 0; i < smallOutputRows; i++) {
			int currentRowLength = strlength(output[i]);
			for (int j = 0; j <= currentRowLength; j++) {
				output[i + smallOutputRows * k][j] = output[i][j];
			}
		}
	}
	// append all chars of currentDigitArray at the end of output
	for (int k = 0; k < length; k++) {
		char currentChar = currentDigitArray[k];
		for (int i = 0; i < smallOutputRows; i++) {
			 int currentRowLength = 
				 strlength(output[i+ smallOutputRows * k]);
			 output[i + smallOutputRows * k][currentRowLength] = 
				 currentChar;
			 output[i + smallOutputRows * k][currentRowLength + 1] =
				 '\0';
		}
	}
	return length*smallOutputRows;
}


int main() {
	int input = 234;
	char output[1000][10];
	int num_rows = keypad(input, output);
	for (int i = 0; i < num_rows; i++) {
		cout << output[i]<< endl;
	}
}

