#include <iostream>
using namespace std;

void replace_pi (char input[], char dest[]) {
	if (input[0] == '\0') {
		dest[0] = '\0';
		return;
	}

	if (input[1] == '\0') {
		dest[0] = input[0];
		dest[1] = '\0';
		return;
	}
	
	if (input[0] == 'p' && input[1] == 'i') {
		dest[0] = '3';
		dest[1] = '.';
		dest[2] = '1';
		dest[3] = '4';
		replace_pi(input + 2, dest + 4);
		return;
	} else {
		dest[0] = input[0];
		replace_pi(input + 1, dest + 1);
		return;
	}


}

int main() {
	char input[30];
	cin >> input;
	char dest[60];
	replace_pi(input, dest);
	cout << dest << endl;
}
