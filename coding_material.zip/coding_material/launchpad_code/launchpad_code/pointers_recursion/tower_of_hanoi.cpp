#include <iostream>
using namespace std;

int print_steps(char source, char helper, char dest, int n) {
	if (n == 1) {
		cout << "Move 1st disk from " << source << "  to " << dest << endl;
		return 1;
	}
	int count = 0;
	count += print_steps(source, dest, helper, n - 1);
	cout << "Move " << n << "th disc from " << source << "  to " << dest << endl;
	count++;
	count += print_steps(helper, source, dest, n - 1);
	return count;
}

int main() {
	cout << "number of steps: " << print_steps('A', 'B', 'C', 14)<< endl;
}

