#include <iostream>
using namespace std;
/*
void increment(int* x) {

	cout << "x" << x << endl;
	int j = 15;

	x = &j;

	(*x)++;
	cout << x << endl;
	cout << *x << endl;
}
*/
void print2(int * input, int n) {

	for (int i = 0; i <n ; i++) {
		cout << *(input + i) << endl;
	}
}

void print(int *input, int n) {
	for (int i = 0; i <n ; i++) {
		cout << *(input + i) << endl;
	}
	print2(input + 1, n -1 );  
}

int main() {
	int i = 10;
	int* ptr = &i;
/*
	int *garbage;
	cout << garbage << endl;
	cout << *garbage << endl;

	cout <<"ptr " << ptr << endl;
	increment(ptr);

	cout << i << endl;
	cout << ptr << endl;	
	*/
	int input[10] =  {1,2,3,4,5,6,7,8,9,10};
//	int* input;
	print(input, 10);
	cout << input << endl;
	cout << input + 1 << endl;
	cout << *input << endl;
	cout << *(input + 1) << endl;

}
