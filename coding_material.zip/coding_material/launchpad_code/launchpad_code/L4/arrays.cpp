#include <iostream>
using namespace std;

void selection_sort(int a[], int n) {
	for (int i = 0; i < n; i++) {
		int minimum = a[i];
		int min_index = i;
		for (int j = i; j < n; j++) {
			if (a[j] < minimum) {
				minimum = a[j];
				min_index = j;
			}
		}
		a[min_index] = a[i];
		a[i] = minimum;
	}
}

int largest(int a[]) {
	int largest_so_far = -10000;
	for (int i = 0; i < 10; i++) {
		if (a[i] > largest_so_far) {
			largest_so_far = a[i];
		}
	}
	return largest_so_far;
}

int linear_search(int a[], int to_be_searched, int size) {
	for (int i = 0; i < size; i++) {
		if (a[i] == to_be_searched) {
			return i;
		}
	}
	return -1;
}

int main() {
  int arr[10];

	for (int i = 0; i < 10; i++) {
		cout << "Enter " << i << "th number" << endl;
		cin >> arr[i];
	}
 
	cout << "printing numbers" << endl;
	//for (int i = 9; i >= 0; i--) {
		//cout << arr[i] << endl;
	//}
 
	cout << largest(arr) << endl;	
	cout << linear_search(arr, 5, 10) << endl;

	cout <<"Before sorting" << endl;
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << endl;
	}

	selection_sort(arr, 10);
	
	cout <<"After sorting" << endl;
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << endl;
	}

}
