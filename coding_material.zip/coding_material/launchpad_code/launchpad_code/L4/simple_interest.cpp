#include <iostream>
using namespace std;

int calculate_interest(int p1, int r, int t) {
	int i = (p1*r*t)/100;
	return i;
}

int main() {
	int p;
	int r;
	int t;

	cout << "Enter the amount\n";
	cin >> p;

	cout << "Enter rate of interest\n";
	cin >> r;

	cout << "Enter duration\n";
	cin >> t;

	int interest = calculate_interest(p,r,t);
	cout << "Interest is: " << interest;
	return 0;
}
