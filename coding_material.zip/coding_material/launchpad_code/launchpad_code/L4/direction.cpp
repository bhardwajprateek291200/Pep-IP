#include <iostream>
using namespace std;

int main() {
	int countN = 0;
	int countS = 0;
	int countE = 0;
	int countW = 0;
	int i = cin.get();
	while (i != '\n') {
		if (i == 'N') {
			countN++;	
		} else if (i == 'S') {
			countS++;
		} else if (i == 'W') {
			countW++;
		} else if (i == 'E') {
			countE++;
		}
		i = cin.get();
	}

	for (int k = 0; k < countE - countW; k++) {
		cout<<'E';
	}

	for (int k = 0; k < countN - countS; k++) {
		cout<<'N';
	}

	for (int k = 0; k < countS - countN; k++) {
		cout<<'S';
	}

	for (int k = 0; k < countW - countE; k++) {
		cout<<'W';
	}
	return 0;
}
