#include <iostream>
using namespace std;

int change(int x) {
	x++;
	cout << x << endl;
	return x;
}

int main() {
  int x = 10;
	x = change(x);
	cout << x << endl;
}

