#include "Node.h"

class DoubleNode {
	public:
		Node* head;
		Node* tail;
};
